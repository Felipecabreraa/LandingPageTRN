<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $mensaje = $_POST['mensaje'];

    // Validación simple
    if (empty($nombre) || empty($email) || empty($mensaje)) {
        $error = "Todos los campos son requeridos.";
    } else {
        // Aquí podrías usar la función mail() para enviar el correo
        $to = "luis.lagos@trn.cl"; // Cambiar por tu correo
        $subject = "Nuevo mensaje de contacto";
        $body = "Nombre: $nombre\nCorreo: $email\nMensaje: $mensaje";
        $headers = "From: $email";

        // Enviar el mensaje
        if (mail($to, $subject, $body, $headers)) {
            $success = "¡Gracias por tu mensaje! Nos pondremos en contacto contigo pronto.";
        } else {
            $error = "Hubo un error al enviar el mensaje. Por favor, intenta nuevamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gracias por contactarnos</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
        }

        .message {
            margin-top: 50px;
            text-align: center;
            font-size: 18px;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }

        .success {
            background-color: #4CAF50;
            color: white;
        }

        .error {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <div class="message <?php echo isset($success) ? 'success' : 'error'; ?>">
        <?php
            if (isset($success)) {
                echo $success;
            } elseif (isset($error)) {
                echo $error;
            }
        ?>
    </div>
    <div class="text-center mt-8">
        <a href="index.html" class="text-yellow-400 hover:text-yellow-500 transition-all">Volver a la página principal</a>
    </div>
</body>
</html>
