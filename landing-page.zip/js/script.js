// Validación de formularios
document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Formulario de contacto enviado");
});

document.getElementById("denunciaForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Denuncia enviada");
});


