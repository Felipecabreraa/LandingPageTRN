<?php
// Configuración de reCAPTCHA
// REEMPLAZA ESTAS CLAVES CON LAS NUEVAS QUE OBTENGAS DE GOOGLE

// Clave del sitio (Site Key) - Se usa en el frontend
define('RECAPTCHA_SITE_KEY', '6LcicF4rAAAAAKP_rL_enSzaVzj0YfSPx-81hhbN');

// Clave secreta (Secret Key) - Se usa en el backend
define('RECAPTCHA_SECRET_KEY', '6LcicF4rAAAAAJl1bQGQ0BUb-mEiSSmu3yRjJyll');

// Dominios permitidos (opcional)
define('RECAPTCHA_ALLOWED_DOMAINS', ['trn.cl', 'www.trn.cl', 'localhost', '127.0.0.1']);
?>
